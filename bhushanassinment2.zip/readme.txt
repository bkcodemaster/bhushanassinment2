username : admin
password : password


userfrom is made in angularjs 
all icon are in svg
for accessing data.json plz start the json serve by giving the path of data.json file
json-server --watch ./pages/data.json
functionlitys
1: login using username and password
2: validation if right input border color turn green and check icon apperas if not red border with error msg apperas
3: for table i ahve used datatable 
4: inside datatable a custome cell is created with the check box
5: when click on check box the ropw get deleted
5: everything is resposive